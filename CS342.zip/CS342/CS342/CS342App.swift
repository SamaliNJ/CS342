//
//  CS342App.swift
//  CS342
//
//  Created by Samali namaganda on 1/12/25.
//

import SwiftUI

@main
struct CS342App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}


