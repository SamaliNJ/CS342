//
//  CS342Test.swift
//  CS342Test
//
//  Created by Samali namaganda on 1/12/25.
//

import Testing

struct CS342Test {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
